# -*- coding: utf-8 -*-
import boto3
from botocore.exceptions import ClientError

def handler(event, context):
  try:
    table = boto3.resource('dynamodb').Table('PizzaShop')
    item = table.get_item(Key={'menu_id': event['menu_id']}).get('Item')
    if item == None:
      response = {}
      return response
    return item
  except Exception as e:
    return e.message