# -*- coding: utf-8 -*-
import boto3
from botocore.exceptions import ClientError

def handler(event, context):
    try:
      client = boto3.client("dynamodb")
      item = client.get_item(TableName="PizzaShop", Key={'menu_id': event['menu-id']}).get('Item')
      if item == None:
        response = {}
        return response
      return item
    except Exception as e:
      return e.message